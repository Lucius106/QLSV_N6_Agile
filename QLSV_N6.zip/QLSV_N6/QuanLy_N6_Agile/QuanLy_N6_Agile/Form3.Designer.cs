﻿namespace QuanLy_N6_Agile
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btn_Thoatt = new Button();
            txt_DiaChi = new TextBox();
            dgv_ThongTinSV = new DataGridView();
            btn_Clear = new Button();
            btn_Xoa = new Button();
            btn_Sửa = new Button();
            btn_Them = new Button();
            rbn_Nu = new RadioButton();
            rbn_Nam = new RadioButton();
            txt_SDT = new TextBox();
            txt_email = new TextBox();
            txt_Ten = new TextBox();
            txt_MaSV = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            ((System.ComponentModel.ISupportInitialize)dgv_ThongTinSV).BeginInit();
            SuspendLayout();
            // 
            // btn_Thoatt
            // 
            btn_Thoatt.Location = new Point(701, 336);
            btn_Thoatt.Name = "btn_Thoatt";
            btn_Thoatt.Size = new Size(94, 29);
            btn_Thoatt.TabIndex = 40;
            btn_Thoatt.Text = "Thoát";
            btn_Thoatt.UseVisualStyleBackColor = true;
            btn_Thoatt.Click += btn_Thoatt_Click;
            // 
            // txt_DiaChi
            // 
            txt_DiaChi.Location = new Point(175, 343);
            txt_DiaChi.Name = "txt_DiaChi";
            txt_DiaChi.Size = new Size(466, 27);
            txt_DiaChi.TabIndex = 39;
            // 
            // dgv_ThongTinSV
            // 
            dgv_ThongTinSV.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgv_ThongTinSV.Location = new Point(45, 390);
            dgv_ThongTinSV.Name = "dgv_ThongTinSV";
            dgv_ThongTinSV.RowHeadersWidth = 51;
            dgv_ThongTinSV.RowTemplate.Height = 29;
            dgv_ThongTinSV.Size = new Size(871, 188);
            dgv_ThongTinSV.TabIndex = 38;
            dgv_ThongTinSV.CellContentClick += dgv_ThongTinSV_CellContentClick;
            // 
            // btn_Clear
            // 
            btn_Clear.Location = new Point(701, 278);
            btn_Clear.Name = "btn_Clear";
            btn_Clear.Size = new Size(94, 29);
            btn_Clear.TabIndex = 37;
            btn_Clear.Text = "Clear";
            btn_Clear.UseVisualStyleBackColor = true;
            btn_Clear.Click += btn_Clear_Click;
            // 
            // btn_Xoa
            // 
            btn_Xoa.Location = new Point(701, 210);
            btn_Xoa.Name = "btn_Xoa";
            btn_Xoa.Size = new Size(94, 29);
            btn_Xoa.TabIndex = 36;
            btn_Xoa.Text = "Xóa";
            btn_Xoa.UseVisualStyleBackColor = true;
            btn_Xoa.Click += btn_Xoa_Click;
            // 
            // btn_Sửa
            // 
            btn_Sửa.Location = new Point(701, 147);
            btn_Sửa.Name = "btn_Sửa";
            btn_Sửa.Size = new Size(94, 29);
            btn_Sửa.TabIndex = 35;
            btn_Sửa.Text = "Sửa";
            btn_Sửa.UseVisualStyleBackColor = true;
            btn_Sửa.Click += btn_Sửa_Click;
            // 
            // btn_Them
            // 
            btn_Them.Location = new Point(701, 87);
            btn_Them.Name = "btn_Them";
            btn_Them.Size = new Size(94, 29);
            btn_Them.TabIndex = 34;
            btn_Them.Text = "Thêm";
            btn_Them.UseVisualStyleBackColor = true;
            btn_Them.Click += btn_Them_Click;
            // 
            // rbn_Nu
            // 
            rbn_Nu.AutoSize = true;
            rbn_Nu.Location = new Point(437, 301);
            rbn_Nu.Name = "rbn_Nu";
            rbn_Nu.Size = new Size(50, 24);
            rbn_Nu.TabIndex = 33;
            rbn_Nu.TabStop = true;
            rbn_Nu.Text = "Nữ";
            rbn_Nu.UseVisualStyleBackColor = true;
            // 
            // rbn_Nam
            // 
            rbn_Nam.AutoSize = true;
            rbn_Nam.Location = new Point(242, 299);
            rbn_Nam.Name = "rbn_Nam";
            rbn_Nam.Size = new Size(62, 24);
            rbn_Nam.TabIndex = 32;
            rbn_Nam.TabStop = true;
            rbn_Nam.Text = "Nam";
            rbn_Nam.UseVisualStyleBackColor = true;
            // 
            // txt_SDT
            // 
            txt_SDT.Location = new Point(175, 244);
            txt_SDT.Name = "txt_SDT";
            txt_SDT.Size = new Size(466, 27);
            txt_SDT.TabIndex = 31;
            // 
            // txt_email
            // 
            txt_email.Location = new Point(175, 194);
            txt_email.Name = "txt_email";
            txt_email.Size = new Size(466, 27);
            txt_email.TabIndex = 30;
            // 
            // txt_Ten
            // 
            txt_Ten.Location = new Point(175, 140);
            txt_Ten.Name = "txt_Ten";
            txt_Ten.Size = new Size(466, 27);
            txt_Ten.TabIndex = 29;
            // 
            // txt_MaSV
            // 
            txt_MaSV.Location = new Point(175, 84);
            txt_MaSV.Name = "txt_MaSV";
            txt_MaSV.Size = new Size(466, 27);
            txt_MaSV.TabIndex = 28;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(48, 345);
            label7.Name = "label7";
            label7.Size = new Size(57, 20);
            label7.TabIndex = 27;
            label7.Text = "Địa Chỉ";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(47, 303);
            label6.Name = "label6";
            label6.Size = new Size(68, 20);
            label6.TabIndex = 26;
            label6.Text = "Giới Tính";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(48, 251);
            label5.Name = "label5";
            label5.Size = new Size(102, 20);
            label5.TabIndex = 25;
            label5.Text = "Số Điện Thoại";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(48, 201);
            label4.Name = "label4";
            label4.Size = new Size(46, 20);
            label4.TabIndex = 24;
            label4.Text = "Email";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(48, 147);
            label3.Name = "label3";
            label3.Size = new Size(56, 20);
            label3.TabIndex = 23;
            label3.Text = "Họ Tên";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(48, 91);
            label2.Name = "label2";
            label2.Size = new Size(95, 20);
            label2.TabIndex = 22;
            label2.Text = "Mã Sinh Viên";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point);
            label1.ForeColor = Color.Red;
            label1.Location = new Point(437, 39);
            label1.Name = "label1";
            label1.Size = new Size(182, 31);
            label1.TabIndex = 21;
            label1.Text = "Cán Bộ Đào Tạo";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // Form3
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(961, 616);
            Controls.Add(btn_Thoatt);
            Controls.Add(txt_DiaChi);
            Controls.Add(dgv_ThongTinSV);
            Controls.Add(btn_Clear);
            Controls.Add(btn_Xoa);
            Controls.Add(btn_Sửa);
            Controls.Add(btn_Them);
            Controls.Add(rbn_Nu);
            Controls.Add(rbn_Nam);
            Controls.Add(txt_SDT);
            Controls.Add(txt_email);
            Controls.Add(txt_Ten);
            Controls.Add(txt_MaSV);
            Controls.Add(label7);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Name = "Form3";
            Text = "Form3";
            ((System.ComponentModel.ISupportInitialize)dgv_ThongTinSV).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btn_Thoatt;
        private TextBox txt_DiaChi;
        private DataGridView dgv_ThongTinSV;
        private Button btn_Clear;
        private Button btn_Xoa;
        private Button btn_Sửa;
        private Button btn_Them;
        private RadioButton rbn_Nu;
        private RadioButton rbn_Nam;
        private TextBox txt_SDT;
        private TextBox txt_email;
        private TextBox txt_Ten;
        private TextBox txt_MaSV;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
    }
}